'''
String 
Substring
Subsequences

'''

def return_subsequences(s1):
    pass


s1 = 'abc'

l1 = return_subsequences(s1)