'''

In-Built Data Structure Python

1. List
2. Tupple
3. Dictionary
4. Sets etc.

'''

s1= ""
s2= ""
s3= ""

student=[]